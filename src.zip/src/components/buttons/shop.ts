import {
    ActionRowBuilder,
    type ButtonInteraction,
    ButtonStyle,
    ChannelType,
    PermissionFlagsBits,
    TextChannel,
    ButtonBuilder,
    DMChannel,
    type StringSelectMenuInteraction,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} from 'discord.js';

import * as config from '../../config';
import { createButtons } from '../../functions';
import UserModel from '../../schemas/User';

export default class Shop {
    async buy(interaction: StringSelectMenuInteraction, type: string) {
        await interaction.deferReply({ ephemeral: true });

        let entry = await UserModel.findOne({ _id: String(interaction.user.id!) }).exec();

        if (!entry) {
            const db = new UserModel({ _id: interaction.user.id });
            await db.save();
        }

        entry = await UserModel.findOne({ _id: String(interaction.user.id) }).exec();

        if (!entry) {
            return await interaction.reply({ content: "An unexpected error occurred, please try again.", flags: 64 });
        }

        if (entry.active_ticket === true) {
            return await interaction.reply({ content: "You can't create multiple tickets at the same time!", flags: 64 });
        }

        //@ts-ignore
        const role = await interaction.guild!.roles.fetch(config.roles[type]);
        if (!role) return;

        const buttons = {
            "buy_close": ["Close Ticket", ButtonStyle.Danger, 1],
        };

        const row = createButtons(Object.keys(buttons), buttons);

        const channel = interaction.guild!.channels.cache.get(String(interaction.channel!.id)) as TextChannel;

        const ticket = await interaction.guild!.channels.create({
            name: `Buyer ${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: channel.parent!.id,
            permissionOverwrites: [
                {
                    id: role.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                        PermissionFlagsBits.AttachFiles
                    ]
                },
                {
                    id: String(interaction.guild!.id),
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: interaction.user.id!,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                },
            ]
        });

        entry.active_ticket = true;
        entry.ticket_id = ticket.id;
        await entry.save();

        const message = await ticket.send({
            content: `<@&${role.id}>, ${interaction.user}`,
            embeds: [
                {
                    title: "Dear customers and buyers!",
                    description: "・ **Please avoid asking [meta-questions](https://nometa.xyz/ru.html) in chat.\n・ This helps us serve you better and faster.**\n\nBest regards, **KAZAMI** <:kazami:1247800883912245272>",
                    color: 10535045,
                    image: {
                        url: "https://cdn.discordapp.com/attachments/847745581329940481/1094248142741979186/image.png"
                    },
                    fields: []
                },
                {
                    description: `### Please describe the product or service details. Our team will reply soon <:kazami:1247800883912245272>\n
### Sample categories:
<#1194041777414488204> - <:nitro:1247791703679565824> \`nitro\` and subscriptions
<#1247514887731544106> - <:designer:1247791695152812154> \`design\` server packs
<#1247518170973999125> - <:designer:1247791695152812154> \`design\` profiles
<#1247518273449361488> - <:designer:1247791695152812154> \`design\` animations
<#1248266505913766090> - <:education:1247791706607456289> \`server\` packs
<#1248273243845169314> - <:developer:1247791698663313429> \`developer\` bots and programs
<#1248266773602500679> - <:education:1247791706607456289> \`server\` resources
<#1248270497867628606> - <:education:1247791706607456289> \`server\` staff training`,
                    color: 10535045,
                    image: {
                        url: "https://cdn.discordapp.com/attachments/847745581329940481/1094248142741979186/image.png"
                    },
                    fields: []
                }
            ],
            components: row
        });

        await ticket.messages.pin(message);
        return await interaction.editReply({ content: `Ticket created! You can ask your questions in ${ticket}` });
    }

    async buy_close(interaction: ButtonInteraction) {
        const entry = await UserModel.findOne({ ticket_id: interaction.channel!.id }).exec();

        if (!entry) {
            return await interaction.reply({ content: "An unexpected error occurred, please try again.", flags: 64 });
        }

        const roles = (await interaction.guild!.members.fetch(interaction.user.id)).roles.cache;
        const hasrole = roles.filter(role => config.approved_roles.includes(role.id));

        if (hasrole.size > 0) {
            const modal = new ModalBuilder()
                .setTitle('Kazami DEV')
                .setCustomId("kazamiDEVModal")
                .addComponents([
                    new ActionRowBuilder<TextInputBuilder>().addComponents(
                        new TextInputBuilder()
                            .setCustomId('product_name')
                            .setStyle(TextInputStyle.Short)
                            .setLabel("Product/Service Name")
                            .setPlaceholder('e.g., Nitro')
                            .setRequired(true),
                    ),
                    new ActionRowBuilder<TextInputBuilder>().addComponents(
                        new TextInputBuilder()
                            .setCustomId('product_price')
                            .setStyle(TextInputStyle.Short)
                            .setLabel("Final Price")
                            .setPlaceholder('e.g., 1000₽')
                            .setRequired(true),
                    )
                ]);

            await interaction.showModal(modal);
        } else {
            const feedbackButton = new ButtonBuilder()
                .setLabel("Leave Feedback")
                .setStyle(ButtonStyle.Link)
                .setURL(`https://discord.com/channels/${interaction.guild!.id}/${config.feedback_channel}`);

            const row = [new ActionRowBuilder<ButtonBuilder>().addComponents(feedbackButton)];

            entry.active_ticket = false;
            await entry.save();

            const dm = await interaction.guild?.members.cache.get(entry._id)!.createDM() as DMChannel;
            dm.send({ content: `Don't forget to leave feedback about our service!`, components: row });

            return await interaction.channel?.delete();
        }
    }

    async close(interaction: ButtonInteraction) {
        const entry = await UserModel.findOne({ ticket_id: interaction.channel!.id }).exec();

        if (!entry) {
            return await interaction.reply({ content: "An unexpected error occurred, please try again.", flags: 64 });
        }

        entry.active_ticket = false;
        await entry.save();
        return await interaction.channel?.delete();
    }

    async teh(interaction: StringSelectMenuInteraction) {
        let entry = await UserModel.findOne({ _id: String(interaction.user.id!) }).exec();

        if (!interaction.guild) return;

        if (!entry) {
            const db = new UserModel({ _id: interaction.user.id });
            await db.save();
        }

        entry = await UserModel.findOne({ _id: String(interaction.user.id) }).exec();

        if (!entry) {
            return await interaction.reply({ content: "An unexpected error occurred, please try again.", flags: 64 });
        }

        if (entry.active_ticket === true) {
            return await interaction.reply({ content: "You can't create multiple tickets at the same time!", flags: 64 });
        }

        const buttons = {
            "close": ["Close Ticket", ButtonStyle.Danger, 1],
        };

        const row = createButtons(Object.keys(buttons), buttons);

        const channel = await interaction.guild!.channels.fetch(String(interaction.channel!.id)) as unknown as TextChannel;

        const ticket = await interaction.guild!.channels.create({
            name: `Support ${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: channel.parent!.id,
            permissionOverwrites: [
                {
                    id: config.manager_role,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                        PermissionFlagsBits.AttachFiles
                    ]
                },
                {
                    id: String(interaction.guild!.id),
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: interaction.user.id!,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                },
            ]
        });

        entry.active_ticket = true;
        entry.ticket_id = ticket.id;
        await entry.save();

        const message = await ticket.send({ content: `<@&${config.manager_role}>`, components: row });
        await ticket.messages.pin(message);

        return await interaction.reply({ content: `Ticket created! You can ask your questions in ${ticket}`, flags: 64 });
    }

    async giveaway(interaction: StringSelectMenuInteraction) {
        let entry = await UserModel.findOne({ _id: String(interaction.user.id!) }).exec();

        if (!entry) {
            const db = new UserModel({ _id: interaction.user.id });
            await db.save();
        }

        entry = await UserModel.findOne({ _id: String(interaction.user.id) }).exec();

        if (!entry) {
            return await interaction.reply({ content: "An unexpected error occurred, please try again.", flags: 64 });
        }

        if (entry.active_ticket === true) {
            return await interaction.reply({ content: "You can't create multiple tickets at the same time!", flags: 64 });
        }

        const buttons = {
            "close": ["Close Ticket", ButtonStyle.Danger, 1],
        };

        const row = createButtons(Object.keys(buttons), buttons);

        const channel = interaction.guild!.channels.cache.get(String(interaction.channel!.id)) as TextChannel;

        const ticket = await interaction.guild!.channels.create({
            name: `Winner ${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: channel.parent!.id,
            permissionOverwrites: [
                {
                    id: config.manager_role,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                        PermissionFlagsBits.AttachFiles
                    ]
                },
                {
                    id: String(interaction.guild!.id),
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: interaction.user.id!,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                },
            ]
        });

        entry.active_ticket = true;
        entry.ticket_id = ticket.id;
        await entry.save();

        const message = await ticket.send({ content: `<@&${config.manager_role}>`, components: row });
        await ticket.messages.pin(message);

        return await interaction.reply({ content: `Ticket created! You can ask your questions in ${ticket}`, flags: 64 });
    }
}
