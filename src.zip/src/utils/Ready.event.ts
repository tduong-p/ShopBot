import { ActionRowBuilder, AttachmentBuilder, ButtonStyle, Client, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, TextChannel } from "discord.js";
import * as config from "../config"

export default class Ready {
    async run(client: Client) {
        const guild = client.guilds.cache.get(config.guild);
        const channel = guild!.channels.cache.get(config.channel) as TextChannel;
        const file = new AttachmentBuilder(`${__dirname}/../../assets/img/start_photo.png`);

        if (!channel || !guild) return;

        const select = new StringSelectMenuBuilder()
            .setCustomId("product_select")
            .setPlaceholder("What would you like to buy?")
            .addOptions(
                new StringSelectMenuOptionBuilder()
                    .setLabel("Development")
                    .setValue("developer")
                    .setEmoji(config.emojis.developer)
                    .setDescription("Buy bot/website/app development services from Dawn Store"),

                new StringSelectMenuOptionBuilder()
                    .setLabel("Design")
                    .setValue("design")
                    .setEmoji(config.emojis.designer)
                    .setDescription("Buy design services from Kazami Design"),

                new StringSelectMenuOptionBuilder()
                    .setLabel("Nitro")
                    .setValue("nitro")
                    .setEmoji(config.emojis.nitro)
                    .setDescription("Buy Discord Nitro from Kazami Shop"),

                new StringSelectMenuOptionBuilder()
                    .setLabel("Staff Training")
                    .setValue("staff")
                    .setEmoji(config.emojis.education)
                    .setDescription("Buy staff training services from Kazami Staff"),

                new StringSelectMenuOptionBuilder()
                    .setLabel("Technical Support")
                    .setValue("help")
                    .setEmoji(config.emojis.support)
                    .setDescription("Contact Kazami's technical support"),

                new StringSelectMenuOptionBuilder()
                    .setLabel("Claim Prize")
                    .setValue("get_prise")
                    .setEmoji(config.emojis.nitrogift)
                    .setDescription("Won a giveaway and want to claim your prize? Click here!")
            )

        const as = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);

        return channel.send({
            content: "",
            tts: false,
            embeds: [
                {
                    color: 10535045,
                    image: {
                        url: "https://media.discordapp.net/attachments/1114971809629089913/1247504826338775093/d16e80bbac7f5453.png"
                    },
                    fields: []
                },
                {
                    color: 10535045,
                    image: {
                        url: "https://media.discordapp.net/attachments/1114971809629089913/1247504823864135710/3e913fc63837e603.png"
                    },
                    fields: [],
                    description: "Need help ordering products or services? Just send a request through our bot <@1209541152102158337>!"
                },
                {
                    title: "**Nitro Full GIFT**",
                    color: 10535045,
                    image: {
                        url: "https://media.discordapp.net/attachments/1114971809629089913/1247504821960048670/Nitro_full_gift.png"
                    },
                    fields: [
                        {
                            name: "💵 Price | 📅 1 Month:",
                            value: "``` 500₽/230₴/2564₸/6$ ```",
                            inline: true
                        },
                        {
                            name: "💵 Price | 📅 1 Year:",
                            value: "``` 3999₽/1659₴/19499₸/43$ ```",
                            inline: true
                        }
                    ]
                },
                {
                    title: "**Nitro Basic GIFT**",
                    color: 10535045,
                    image: {
                        url: "https://media.discordapp.net/attachments/1114971809629089913/1247504816041758731/Nitro_basic_gift.png"
                    },
                    fields: [
                        {
                            name: "💵 Price | 📅 1 Month:",
                            value: "``` 249₽/99₴/1249₸/3$```",
                            inline: true
                        },
                        {
                            name: "💵 Price | 📅 1 Year:",
                            value: "``` 1999₽/829₴/9899₸/22$```",
                            inline: true
                        }
                    ]
                }
            ],
            components: [as],
        });
    };
};
